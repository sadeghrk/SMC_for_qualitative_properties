Many of these images are taken from or based on those from	Everaldo Coelho's
Crystal icon set (details below) which is released under LGPL.

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
This copyright and license notice covers the images in this directory.
************************************************************************

TITLE:	Crystal Project Icons
AUTHOR:	Everaldo Coelho
SITE:	http://www.everaldo.com
CONTACT: everaldo@everaldo.com

Copyright (c)  2006-2007  Everaldo Coelho.

