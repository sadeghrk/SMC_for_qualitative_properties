/* Forwarding header in the legacy location, pointing to the new location of the JNI auto-generated header file */
#include "jni/prism_NativeIntArray.h"
